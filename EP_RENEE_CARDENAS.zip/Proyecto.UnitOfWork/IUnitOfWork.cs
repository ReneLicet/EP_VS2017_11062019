﻿using Proyecto.Repositories.Cineo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.UnitOfWork
{
    public interface IUnitOfWork
    {
        IProductoRepository Productos { get; }
        IResenaRepository Resenas { get; }

    }
}
