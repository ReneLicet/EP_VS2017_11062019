﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Model
{
    public class ListaProductoViewModel
    {
        public IEnumerable<Producto> Relojes { get; set; }
        public IEnumerable<Producto> Celulares { get; set; }
        public IEnumerable<Producto> Computadoras { get; set; }

    }
}
