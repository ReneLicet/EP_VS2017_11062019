﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Model
{
    public enum CategoriaEnum
    {
        RELOJES = 1,
        CELULARES = 2,
        COMPUTADORAS = 3
    }
}
