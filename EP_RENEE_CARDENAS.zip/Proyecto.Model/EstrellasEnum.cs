﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Model
{
    public enum EstrellasEnum
    {
        UNO = 1,
        DOS = 2,
        TRES = 3,
        CUATRO = 4,
        CINCO = 5
    }
}
