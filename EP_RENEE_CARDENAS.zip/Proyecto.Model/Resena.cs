﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Model
{
    public class Resena
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Comentario { get; set; }
        public int Calificacion { get; set; }
        public int ProductoId { get; set; }
    }
}
