﻿using Proyecto.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Repositories.Cineo
{
    public interface IProductoRepository : IRepository<Producto>
    {

    }
}
