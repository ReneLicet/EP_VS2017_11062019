﻿using Proyecto.Repositories.Cineo;
using Proyecto.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Repositories.Dapper.Cineo
{
    public class CineoUnitOfWork : IUnitOfWork
    {
        public CineoUnitOfWork(string connectionString)
        {
            Productos = new ProductoRepository(connectionString);
            Resenas = new ResenaRepository(connectionString);
        }
        public IProductoRepository Productos { get; private set; }
        public IResenaRepository Resenas { get; private set; }
    }
}
