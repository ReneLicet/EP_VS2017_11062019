﻿using Proyecto.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto.Mvc.ViewModel
{
    public class DetalleProductoViewModel
    {
        public Producto Producto { get; set; }
        public IEnumerable<Resena> Resenas { get; set; }
    }
}