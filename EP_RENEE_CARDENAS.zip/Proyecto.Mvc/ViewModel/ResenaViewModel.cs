﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace Proyecto.Mvc.ViewModel
{
    public class ResenaViewModel
    {
        //public Resena Resena { get; set; }
        public string Titulo { get; set; }
        public string Comentario { get; set; }
        public int ProductoId { get; set; }
        public int CalificacionId { get; set; }
        public IEnumerable<SelectListItem> Calificaciones { get; set; }
    }
}