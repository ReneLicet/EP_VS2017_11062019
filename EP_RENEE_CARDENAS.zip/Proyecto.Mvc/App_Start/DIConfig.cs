﻿using Proyecto.Repositories.Dapper.Cineo;
using Proyecto.UnitOfWork;
using SimpleInjector;
using SimpleInjector.Integration.Web;
using SimpleInjector.Integration.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Proyecto.Mvc.App_Start
{
    public class DIConfig
    {
        public static void ConfigureInjector() {
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new WebRequestLifestyle();
            var connectionString = ConfigurationManager.ConnectionStrings["CineoConnection"].ToString();
            container.Register<IUnitOfWork>(() => new CineoUnitOfWork(connectionString));
            container.RegisterMvcControllers(Assembly.GetExecutingAssembly());

            container.Verify();
            DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(container));
        }
    }
}
