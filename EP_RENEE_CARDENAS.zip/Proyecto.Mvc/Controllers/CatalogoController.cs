﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Proyecto.Model;
using Proyecto.Mvc.ViewModel;
using Proyecto.UnitOfWork;

namespace Proyecto.Mvc.Controllers
{
    public class CatalogoController : BaseController
    {
        public CatalogoController(IUnitOfWork unit) : base(unit)
        {
        }
        public ActionResult Index() {
            var productos = _unit.Productos.GetList();
            var modelo = new ListaProductoViewModel
            {
                Relojes = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.RELOJES),
                Celulares = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.CELULARES),
                Computadoras = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.COMPUTADORAS)
            };
            return View(modelo);
        }
        public ActionResult VerOferta()
        {
            var productos = _unit.Productos.GetList().Where(p => p.EnOferta == true);
            var modelo = new ListaProductoViewModel
            {
                Relojes = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.RELOJES),
                Celulares = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.CELULARES),
                Computadoras = productos.Where(p => p.CategoriaId == (int)CategoriaEnum.COMPUTADORAS)
            };
            return View(modelo);
        }
        public ActionResult VerProducto(int Id) {
            var producto = _unit.Productos.GetById(Id);
            if (producto == null)
            {
                return RedirectToAction("Index");
            }
            var resenas = _unit.Resenas.GetList().Where(p=>p.ProductoId==Id);
            var detalleProductoViewModel = new DetalleProductoViewModel();
            detalleProductoViewModel.Producto=producto;
            detalleProductoViewModel.Resenas = resenas;
            return View(detalleProductoViewModel);
        }
    }
}
