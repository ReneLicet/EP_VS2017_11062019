﻿using Proyecto.Model;
using Proyecto.Mvc.Code;
using Proyecto.Mvc.ViewModel;
using Proyecto.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Proyecto.Mvc.Controllers
{
    public class ResenaController : BaseController
    {
        public ResenaController(IUnitOfWork unit) : base(unit)
        {
        }
        public ActionResult Crear(int Id)
        {
            var resena = new ResenaViewModel();
            var calificaciones = Util.GetEnumSelectList<EstrellasEnum>();
            resena.ProductoId = Id;
            resena.Calificaciones = calificaciones;
            return View(resena);
        }


        [HttpPost]
        public ActionResult Crear(ResenaViewModel resena)
        {
            var resenaModel = new Resena();
            resenaModel.ProductoId = resena.ProductoId;
            resenaModel.Titulo = resena.Titulo;
            resenaModel.Comentario = resena.Comentario;
            resenaModel.Calificacion = resena.CalificacionId;
            _unit.Resenas.Insert(resenaModel);
            return RedirectToAction("Index", "Catalogo");
        }
    }
}
